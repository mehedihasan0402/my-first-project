import React, {useContext, useEffect, useState} from "react";
import {AuthContext} from "../../contexts/AuthProvider";
import axios from "axios";
import {Link} from "react-router-dom";

const Conversations = () => {
    const {user} = useContext(AuthContext);
    const {email: userEmail} = user || {}
    const [conversations, setConversations] = useState([])

    useEffect(() => {
        async function fetchData() {
            const response = await axios.get(`http://localhost:5000/conversations/${userEmail}`) || {}

            setConversations(response?.data?.conversations || []);
        }
        fetchData();
    }, []);

    const getParticipantName = (participants = []) => {
        const participantInfo = participants.find((participant) => participant.email !== userEmail);

        return participantInfo?.name;
    };

    return (
        <>
            <div style={{margin: "4em 0"}}>
                <h1>Conversations</h1>
                <ul className="list-group">
                    {
                        conversations.map((conversation) => (
                            <Link className="list-group-item"
                                  to={`/conversation-messages/${conversation?._id}`}>{getParticipantName(conversation?.participants)}</Link>
                        ))
                    }
                </ul>
            </div>
        </>
    )
};

export default Conversations;